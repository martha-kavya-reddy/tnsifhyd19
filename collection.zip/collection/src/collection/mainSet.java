package collection;
import java.util.Iterator;
import java.util.HashSet;

public class mainSet {
		    public static void main(String[] args)
		    {
	        HashSet<String>hs = new  HashSet<String>();
	        hs.add("hello");
	        hs.add("welcome to");
	        hs.add("sri indu");
	  hs.add("college");
	  hs.add("hello");
	  Iterator<String>itr=hs.iterator();
	  while(itr.hasNext()) {
		  System.out.println(itr.next());
	  }
}
	  }
	        
