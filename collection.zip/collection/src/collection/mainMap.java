package collection;
import java.util.Map;
import java.util.HashMap;

public class mainMap {
    public static void main(String[] args) {
        HashMap<Integer,String>hm = new HashMap<Integer,String>();
        hm.put(1,"sri");
        hm.put(2,"indu");
        hm.put(3,"college of");
        hm.put(4,"engineering");
        hm.put(5,"and technology");
        System.out.println("Value for 1 is "+hm.get(1));
for(Map.Entry<Integer,String>e:hm.entrySet())
	System.out.println(e.getKey()+" "+e.getValue());
    }
}

       