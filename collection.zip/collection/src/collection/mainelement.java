package collection;

import java.util.ArrayList;

public class mainelement {
	public static void main(String[] args) {
		  
        ArrayList<Integer> al = new ArrayList<Integer>();

        for (int i = 1; i <= 6; i++)
            al.add(i);
        System.out.println(al);
        al.remove(4);
        System.out.println(al);
        for (int i = 0; i< al.size(); i++)
            System.out.println(al.get(i)+" ");
    }
}

	