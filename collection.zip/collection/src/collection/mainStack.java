package collection;
import java.util.Iterator;
import java.util.Stack;

public class mainStack {
    public static void main(String[] args) {
        Stack<String> Stack= new Stack<String>();
        Stack.push("sri");
        Stack.push("indu");
        Stack.push("college of");
        Stack.push("engineering");
        Stack.push(" and technology");
        Iterator<String>itr=Stack.iterator();
while(itr.hasNext()) {
        System.out.println(itr.next()+" ");
}
System.out.println();
        Stack.pop();
        itr=Stack.iterator();
        while(itr.hasNext()) {
            System.out.println(itr.next()+" ");
    }
	}

}

