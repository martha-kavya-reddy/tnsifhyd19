package accessmodifiers;
public class mainteacher {
	public static void main(String[] args) {
		teacher t =new teacher();
		System.out.println(t.idno);
		t.printidno();
	}
}