package accessmodifiers;

public class mainstudent {
	public static void main(String[] args) {
		student s=new student();
		System.out.println(s.rollno);
		s.printrollnumber();
	}

}
