package accessmodifiers;

public class customer {
		int serialno =1;
		 customer() {
			serialno=4;
		}
	 void printserialno() {
			System.out.println(serialno);
			
		}
}