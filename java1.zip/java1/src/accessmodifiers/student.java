package accessmodifiers;

public class student {
	public int rollno=101;
	public student() {
		rollno=102;
		
	}
	public void printrollnumber() {
		System.out.println(rollno);
	}
}