package accessmodifiers;

public class maincustomer {

	public static void main(String[] args) {
			customer c =new customer();
			System.out.println(c.serialno);
			c.printserialno();


	}

}
