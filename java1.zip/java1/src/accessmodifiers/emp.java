package accessmodifiers;

public class emp {
	private int idno =103;
	private emp() {
		idno=104;
	}
	private void printidno() {
		System.out.println(idno);
		
	}
public static void main(String[] args) {
	emp e = new emp();
	e.abc();
}
public void abc() {
	printidno();
}
}
