package accessmodifiers;

public class teacher {
	protected	int idno =100;
		 teacher() {
			idno=200;
		}
	protected void printidno() {
			System.out.println(idno);
			
		}

public static void main(String[] args) {
	teacher t = new teacher();
	t.abc();
}
public void abc() {
	printidno();
}
}

	
