

	package Encapsulation;
	public class enclose2 {
		private String fullname = "marthaKavya";
		private int salary =50000;
		private String address = "hyderabad";
	public String getfullname() {
		return fullname;
	}
	public void setfullname(String fullname) {
		this.fullname = fullname;
	}
	public int getsalary() {
	 	return salary;
	}
	public void setsalary(int salary) {
		this.salary=salary;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress( String address) {
		this.address=address;
	}
}
