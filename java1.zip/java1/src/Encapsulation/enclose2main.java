package Encapsulation;

public class enclose2main {
	public static void main(String[] args) {
		enclose2 e2 = new enclose2();		
e2.setfullname("marthakavya");
e2.setsalary(50000);
e2.setaddress("hyderabad");
System.out.println(e2 .getfullname());
System.out.println(e2 .getsalary());
System.out.println(e2 .getaddress());


}

}
