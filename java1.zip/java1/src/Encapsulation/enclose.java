package Encapsulation;

public class enclose {
	public String fullname = "marthaKavya";
	public int salary= 50000;
	public String address= "hyderabad";
	
}
