package Encapsulation;

public class enclose1 {
	private String fullname = "marthaKavya";
	private int salary =50000;
	private String address= "hyderabad";
	
    public String getfullname() {
	    return fullname;
    }
    public int getsalary() {
    	return salary;
    }
    public String getaddress() {
    	return address;
    }
    
   
			
	public static void main(String[] args) {
		enclose1 e1 = new enclose1();
		System.out.println(e1.getfullname());
		System.out.println(e1.getsalary());
		System.out.println(e1.getaddress());

	}

}
