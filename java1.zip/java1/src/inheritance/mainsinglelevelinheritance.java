package inheritance;

public class mainsinglelevelinheritance {

		public static void main(String[] args) {
		child1 c=new child1();
			c.parentinfo();
			c.child1info();

		}

	}


