package inheritance;
class grandparent{
String name="sathireddy";
String surname="Martha";
void grandparentinfo() {
	System.out.println("name of the grandparent:"+name);
	System.out.println("surname of the grandparent:"+surname);
}
}
class parent extends grandparent{
	String name="kavya";
	void parentinfo() {
		System.out.println("name of the parent:"+name);
		System.out.println("surname of the parent:"+surname);
	}
}
class child extends parent{
	String name="papa";
	void childinfo() {
		System.out.println("name of the child:"+name);
		System.out.println("surname of the child:"+surname);
	}
}
public class mainmultilevel{
	public static void main(String[] args) {
		child c=new child();
		c.grandparentinfo();
		c.parentinfo();
		c.childinfo();
		
		
	}
	
}













