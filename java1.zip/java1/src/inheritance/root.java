package inheritance;

public class root {
	String firstname="Kavya";
	String surname="Martha";
	void parentinfo() {
		System.out.println("First Name of parent:"+firstname);
		System.out.println("surname of parent:"+surname);
	}
	}
class child1 extends parent{
String firstname="chinni";
void child1info() {
	System.out.println("firstname of child1:"+firstname);
	System.out.println("surname of child1:"+surname);
}
}
