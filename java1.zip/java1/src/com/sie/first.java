package com.sie;

class first {
		static void display() {
		System.out.println("hello");
			}
}
	class second extends first {
		static void display() {
			System.out.println("world");
		}
	}

