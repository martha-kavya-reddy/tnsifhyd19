package com.sie;
class tmain {

	public static void main(String[] args) {
		four f2=new four();
		f2.display();

	}

}
