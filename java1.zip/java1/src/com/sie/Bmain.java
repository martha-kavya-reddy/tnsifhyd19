package com.sie;
class Bmain {
public static void main(String[] args) {
		B.display();
	}		
}
