package com.sie;

public class ctor {
	
	private String doors;
	private String light;
	private String work;
	
	
	public ctor() {
		doors = "open";
		light = "on";
		work= "started";
		
	}
	
	public String display() {
		if(doors.equals("open") && light.equals("on")&& work.equals("started")) {
			return "shop is running";
		}
		else{
			return "shop is not running";
		}
	}

}
