package com.sie;
class cupmain {
public static void displayTeamStats(String teamName, int runs, int wickets) {
	        System.out.println(teamName + " Stats:");
	        System.out.println("Runs: " + runs);
	        System.out.println("Wickets: " + wickets);
	        System.out.println();
	    }
		
	}

