package com.sie;
class sample {
	int a=10;
	static int b=20;
	public static void main(String[] args) {
		int c=30;
		sample s1=new sample();
		System.out.println(s1.a);
		System.out.println(sample.b);
		System.out.println(c);
	}
}