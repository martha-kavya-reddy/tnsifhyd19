package com.sie;
class parent {
	void display() {
		System.out.println("father");
	}
}
class child extends parent {
	void display() {
		System.out.println("son");
			}
		}


