package com.sie;


public class ctorparametermain {

		public static void main(String[] args) {
				ctorparameter c2= new ctorparameter("open","on","started");
				System.out.println(c2.run());
				}
		}


