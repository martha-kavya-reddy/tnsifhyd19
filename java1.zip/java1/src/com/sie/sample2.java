package com.sie;

public class sample2 {
	
	public static void main(String[] args) {
		sample1 s1=new sample1();
		System.out.println(s1.a);	
		System.out.println(sample1.display1());
		System.out.println(sample1.b);
		s1.display();
		int c=90;
		System.out.println(c);

		
		

	}

}
