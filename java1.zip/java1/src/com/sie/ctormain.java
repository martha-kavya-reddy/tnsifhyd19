package com.sie;

public class ctormain {

	public static void main(String[] args) {
			ctor c1 = new ctor();
			System.out.println(c1.display());
			}
	}
