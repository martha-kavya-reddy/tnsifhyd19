package com.sie;
class pmain {
public static void main (String[] args) {
		child c1=new child();
		c1.display();
}
}
