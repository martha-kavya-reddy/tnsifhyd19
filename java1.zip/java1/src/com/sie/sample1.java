package com.sie;

public class sample1 {
			int a=10;
			static int b=20;
		void display() {
			System.out.println("hello");
		}
			static String display1() {
				return "world"; 
			}
			
		}
			
		

		