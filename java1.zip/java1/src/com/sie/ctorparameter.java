package com.sie;

public class ctorparameter {
	
	private String doors;
	private String light;
	private String work;

	

	public ctorparameter(String doors, String light, String work) {
		this.doors = doors; 
		this.light = light;
		this.work = work;
	
	}
 
	public String run() {
		if(doors.equals("open") && light.equals("on")&& work.equals("started")) 
			 {
			return "work is running";
		}else {
			return "work is not running";
		}
	}

}



