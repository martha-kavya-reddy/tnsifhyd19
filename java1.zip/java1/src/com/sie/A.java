package com.sie;
class A {
	static int display() {
		return 10;
	}
}
class B extends A{
	static int display() {
		return 20;
	}
}
