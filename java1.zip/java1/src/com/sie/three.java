package com.sie;
class three {
	int display() {
		return 10;
	}
}
class four extends three {
	int display() {
		return 6;
	}
}

	


