package com.sie;

public class worldcup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
