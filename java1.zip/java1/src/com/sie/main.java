package com.sie;
class main {
public static void main(String[] args) {
		second.display();
		

	}

}
