package Com.Strings;

public class StringBuilderExample4 {

	public static void main(String[] args) {
							StringBuffer sb = new StringBuffer("Welcome");
							sb.delete(1,5);
							System.out.println(sb);
			}
	
}
