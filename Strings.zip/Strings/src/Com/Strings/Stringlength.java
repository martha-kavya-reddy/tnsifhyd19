package Com.Strings;

public class Stringlength {

	public static void main(String[] args) {
		char c[]={'k','a','v','y','a'};
		String s=new String(c);
		System.out.println(s.length());
		
	}
}
