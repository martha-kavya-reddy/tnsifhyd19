package Com.Strings;

public class Stringcomparsion {

	public static void main(String[] args) {
		String s1="hello";	
		String s2="hello";	
        String s3="hi ";	
        String s4="HELLO";	
        System.out.println(s1.equals(s2));
        System.out.println(s1.equals(s3));
        System.out.println(s2.equalsIgnoreCase(s4));
        System.out.println(s3.equals(s1));
		
	}
}