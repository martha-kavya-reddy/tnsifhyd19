package Com.Strings;

public class StringBuilderExample3 {
		public static void main(String[] args) {
						StringBuffer sb = new StringBuffer("Welcome");
						sb.replace(1,3,"sri indu");
						System.out.println(sb);
		}
	}