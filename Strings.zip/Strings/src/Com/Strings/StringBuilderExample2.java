package Com.Strings;

public class StringBuilderExample2 {

	public static void main(String[] args) {
	StringBuffer sb = new StringBuffer("Welcome");
    sb.insert(1,"sri indu");
   System.out.println(sb);
			}
		}