package Com.Strings;

public class Stringcomparison1 {

	public static void main(String[] args) {
		String s1="This is Exam";
		String s2="THIS IS EXAM";
		String s3="This is Exam";
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s2==s3);
	}
}
		
		