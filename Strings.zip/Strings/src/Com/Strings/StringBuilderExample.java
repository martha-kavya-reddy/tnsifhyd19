package Com.Strings;

public class StringBuilderExample {
	public static void main(String[] args) {
					StringBuffer sb = new StringBuffer("Welcome");
					sb.append("sri indu");
					System.out.println(sb);
	}
}