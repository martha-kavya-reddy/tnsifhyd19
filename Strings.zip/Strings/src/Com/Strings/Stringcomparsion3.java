package Com.Strings;

public class Stringcomparsion3 {

	public static void main(String[] args) {
		String s1="kavya";
		String s2="Navya";
		String s3="Kavya";
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println(s2.compareTo(s3));
		System.out.println(s2.compareTo(s3));
		System.out.println(s3.compareTo(s3));
	}

}
